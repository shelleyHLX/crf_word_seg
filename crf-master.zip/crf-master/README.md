# crf
keras implement of conditional random field

It's probably the shortest CRF implementation.

https://kexue.fm/archives/5542

## 交流
QQ交流群：67729435，微信群请加机器人微信号spaces_ac_cn
